import time
import sys
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from db_op import *

#------ Funciones del BOT -------#

def encontrar_elemento(driver, espera, locator):
    while True:
        try:
            elemento_web = espera.until(EC.presence_of_element_located(locator))
            if elemento_web:
                return elemento_web
        except TimeoutException as e:
            mensaje_error = f"Error: Tiempo de espera agotado al buscar el elemento. {str(e)}"
            registrar_error(mensaje_error)
            return None
        except Exception as e:
            mensaje_error = f"Error: No se pudo encontrar el elemento.{str(e)}"
            registrar_error(mensaje_error)
            return None
        time.sleep(1)

    
def registrar_ejecucion_exitosa():
    with open("run_log.txt", "a") as archivo:
        fecha_hora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        mensaje_ejecucion = f"[{fecha_hora}] BOT Wikipedia Incializado Correctamente.\n"
        archivo.write(mensaje_ejecucion)
        print(mensaje_ejecucion)


def busqueda_raspado_elementos():
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    driver = None
    iteracion = True
    contador = 1

    conexion = inicializar_conexion()
    url_nav = url_busqueda()

#----------- BOT -------------#
    
    while True:
        try:
            if iteracion:
                driver = webdriver.Chrome(options=options)
                iteracion = False
            else:
                driver.refresh()

            driver.get(url_nav)
            espera = WebDriverWait(driver, 1)
            palabra_buscar =palabra_busqueda()

            estado_apagado = verificar_apagado(conexion)
            if estado_apagado:
                print("El bot ha sido apagado desde la base de datos.")
                break
            
            if not palabra_buscar or not url_nav:
                mensaje_error = "Palabra o Url no encontrada y/o valida... Reintentando"
                registrar_error(conexion, mensaje_error)
                time.sleep(5)

                continue
            
            caja_busqueda = encontrar_elemento(driver, espera, (By.NAME, "q"))
            caja_busqueda.send_keys(palabra_buscar)
            caja_busqueda.send_keys(Keys.ENTER)
            time.sleep(3)

            link_wikipedia = encontrar_elemento(driver, espera, (By.LINK_TEXT, "Wikipedia"))
            if link_wikipedia:
                link_wikipedia.click()
                titulo = encontrar_elemento(driver, espera, (By.XPATH,'//*[@id="firstHeading"]/span'))
                texto_titulo = titulo.text
                introduccion = encontrar_elemento(driver, espera, (By.XPATH, '//*[@id="mw-content-text"]/div[1]/p[1]'))
                texto_introduccion = introduccion.text
                historia = encontrar_elemento(driver, espera, (By.XPATH, '//*[@id="mw-content-text"]/div[1]/p[2]'))
                texto_historia = historia.text
                componente = encontrar_elemento(driver, espera, (By.XPATH, '//*[@id="mw-content-text"]/div[1]/p[3]'))
                texto_componente = componente.text

                #---- Verificaciones contenido de variables dentro de consola o terminal ----#

                print("Titulo:", texto_titulo)
                print("\n")
                print("Primer párrafo:", texto_historia)
                print("\n")
                print("Segundo párrafo:", texto_introduccion)
                print("\n")
                print("Tercer párrafo:", texto_componente)

                #---- Insercion de datos en base de datos MySQL ----#
                conexion= inicializar_conexion()
                insertar_datos(conexion,texto_titulo, texto_introduccion, texto_historia, texto_componente)
                registrar_ejecucion_exitosa()
                contador = 1

        except Exception as e:
            print("Error en la obtención de los elementos en la página:", str(e))
            print("No se pudo completar la Operación. Intente de nuevo")
            print("Automatizacion Fallida:", 'Error de tiempo de espera')
            registrar_error(conexion,str(e))

            contador += 1

        if contador > 60:
            sys.exit()

        if len(driver.window_handles) == 0:
            mensaje_error = "Error Catastrófico: La ventana del navegador ha sido cerrada."
            registrar_error(mensaje_error)
            print("La ventana del navegador ha sido cerrada. El Bot se detendrá ahora")
            sys.exit()

        time.sleep(5)


busqueda_raspado_elementos()