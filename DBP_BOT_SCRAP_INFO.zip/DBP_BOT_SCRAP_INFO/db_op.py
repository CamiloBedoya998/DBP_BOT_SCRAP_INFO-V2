import datetime
import mysql.connector
from Encrypt_Decrypt import *


def obt_credenciales_cyph():
    host ="Localhost"
    user = "root"
    password = "password"

    cyph_host = Encrypt(host)
    cyph_user = Encrypt(user)
    cyph_password = Encrypt(password)

    return cyph_host, cyph_user, cyph_password


def url_busqueda():
    conexion = inicializar_conexion()
    cursor = conexion.cursor()

    consulta = "SELECT RCON_PG_NAV FROM tbl_rcontrol WHERE RCON_ESTADO = 'Activo' ORDER BY PK_RCON_ID ASC LIMIT 1"
    cursor.execute(consulta)
    url_buscar = cursor.fetchone()

    cursor.close()
    cerrar_conexion(conexion)

    if url_buscar:
        return url_buscar[0]
    else:
        return None


def palabra_busqueda():
    conexion = inicializar_conexion()
    cursor = conexion.cursor()
    
    consulta = "SELECT RCON_PALABRA FROM tbl_rcontrol WHERE RCON_ESTADO = 'Activo' ORDER BY PK_RCON_ID ASC LIMIT 1"
    cursor.execute(consulta)
    palabra = cursor.fetchone()

    cursor.close()
    cerrar_conexion(conexion)

    if palabra:
        return palabra[0]
    else:
        return None


def inicializar_conexion():
    cyph_host, cyph_user,cyph_password = obt_credenciales_cyph()
    host= DeCrypt(cyph_host)
    user= DeCrypt(cyph_user)
    pasword= DeCrypt(cyph_password)
    
    iniciar_conexion = mysql.connector.connect(
        host=host,
        user=user,
        password=pasword,
        database="dbp_bot_scrap_info"
    )
    return iniciar_conexion


def registrar_error(conexion, mensaje_error):
    print("Mensaje de error en db_op:", mensaje_error)
    with open("log.txt", "a") as archivo:
        fecha_hora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        mensaje_log = f"[{fecha_hora}] Error: {mensaje_error}\n"
        archivo.write(mensaje_log)
        print(mensaje_log)

    cursor = conexion.cursor()
    consulta = "INSERT INTO tbl_log (LOG_CONT) VALUES (%s)"
    datos_error = (mensaje_error,)
    print("Consulta:", consulta)
    print("Datos:", datos_error)
    cursor.execute(consulta, datos_error)
    conexion.commit()
    cursor.close()


def insertar_control(conexion, host, usuario, pg_nav, password, palabra, estado="Activo"):
    cursor = conexion.cursor()
    consulta = "INSERT INTO tbl_rcontrol (RCON_HOST, RCON_USER, RCON_PG_NAV, RCON_PASSWORD, RCON_PALABRA, RCON_ESTADO) VALUES (%s, %s, %s, %s, %s, %s)"
    datos_control = (host, usuario, pg_nav, password, palabra, estado)
    cursor.execute(consulta, datos_control) 
    conexion.commit()
    cursor.close()


def limpiar_contenido(texto):
    if texto is None:
        return None
    return texto.replace("'","").replace('"','')


def insertar_datos(conexion, titulo, introduccion, historia, componente):
    titulo = limpiar_contenido(titulo)
    introduccion =limpiar_contenido(introduccion)
    historia=limpiar_contenido(historia)
    componente=limpiar_contenido(componente)
    
    cursor = conexion.cursor()
    consulta = "INSERT INTO tbl_scrap (SCRA_TITULO, SCRA_INTRO, SCRA_HISTORIA, SCRA_COMPONENTE, SCRA_ESTADO) VALUES (%s, %s, %s, %s, %s)"
    datos_raspado = (titulo, introduccion, historia, componente, "Activo")
    cursor.execute(consulta, datos_raspado) 
    conexion.commit()
    cursor.close()


def verificar_apagado(conexion):
    cursor = conexion.cursor()
    consulta = "SELECT RCON_INICIO_APAGADO FROM tbl_rcontrol WHERE RCON_ESTADO = 'Activo' ORDER BY PK_RCON_ID ASC LIMIT 1"
    cursor.execute(consulta)
    resultado = cursor.fetchone()
    cursor.close()

    if resultado and resultado[0] == 0:  # Suponiendo que 0 significa que el bot debe apagarse
        return True
    else:
        return False

    
def cerrar_conexion(conexion):
    conexion.close()