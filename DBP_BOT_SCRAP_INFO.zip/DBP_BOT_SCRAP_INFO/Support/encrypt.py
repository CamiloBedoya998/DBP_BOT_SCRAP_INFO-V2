from Encrypt_Decrypt import*

host ="Localhost"
user = "root"
password = "password"

print(Encrypt(host))
print(Encrypt(user))
print(Encrypt(password))

cyph_host='41525A3245774C6D41775232446D4C3441784C335A6D7030'
cyph_user='416D563245774D54416D443D'
cyph_password='416D4E325A47706D416D5A33416D4D54416D5632414E3D3D'

print("\n")
print("\n")

print(DeCrypt(cyph_host))
print(DeCrypt(cyph_user))
print(DeCrypt(cyph_password))


